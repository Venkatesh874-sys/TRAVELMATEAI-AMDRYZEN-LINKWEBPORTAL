/* ============================================================
   TRAVELMATE AI — TOPBAR COMPONENT
   js/components/topbar.js
   ============================================================ */

const Topbar = (() => {

  function render() {
    return Helpers.el('header', {
      className: 'topbar',
      html: `
        <div class="topbar__brand">
          <span class="topbar__logo">✈️</span>
          <span class="topbar__name">TravelMate AI</span>
        </div>
        <div class="topbar__status">
          <div class="topbar__dot"></div>
          <span>AI Online</span>
        </div>
      `
    });
  }

  return { render };
})();
