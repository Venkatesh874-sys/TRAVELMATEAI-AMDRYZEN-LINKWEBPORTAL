/* ============================================================
   TRAVELMATE AI — BOTTOM NAVIGATION COMPONENT
   js/components/nav.js
   ============================================================ */

const Nav = (() => {

  const NAV_ITEMS = [
    { id: 'dashboard',  icon: 'home',      label: 'Home'      },
    { id: 'planner',    icon: 'map',       label: 'Plan'      },
    { id: 'translator', icon: 'translate', label: 'Translate' },
    { id: 'discover',   icon: 'star',      label: 'Discover'  },
    { id: 'payment',    icon: 'dollar',    label: 'Pay'       },
    { id: 'creator',    icon: 'camera',    label: 'Create'    },
    { id: 'safety',     icon: 'alert',     label: 'Safety'    },
    { id: 'profile',    icon: 'user',      label: 'Profile'   },
  ];

  let navEl = null;
  let currentPage = 'dashboard';
  let onNavCallback = null;

  function render() {
    navEl = Helpers.el('nav', { className: 'bottom-nav glass' });

    NAV_ITEMS.forEach(item => {
      const btn = Helpers.el('div', {
        className: `nav-item ${currentPage === item.id ? 'active' : ''}`,
        attrs: { 'data-page': item.id, 'role': 'button', 'tabindex': '0', 'aria-label': item.label },
        html: `
          ${Icons.get(item.icon, 18)}
          <span>${item.label}</span>
        `,
        on: {
          click: () => navigate(item.id),
          keydown: (e) => { if (e.key === 'Enter' || e.key === ' ') navigate(item.id); }
        }
      });
      navEl.appendChild(btn);
    });

    return navEl;
  }

  function navigate(pageId) {
    currentPage = pageId;
    // Update active state
    if (navEl) {
      navEl.querySelectorAll('.nav-item').forEach(btn => {
        btn.classList.toggle('active', btn.dataset.page === pageId);
      });
    }
    if (typeof onNavCallback === 'function') onNavCallback(pageId);
  }

  function setActive(pageId) {
    currentPage = pageId;
    if (navEl) {
      navEl.querySelectorAll('.nav-item').forEach(btn => {
        btn.classList.toggle('active', btn.dataset.page === pageId);
      });
    }
  }

  function onNavigate(callback) {
    onNavCallback = callback;
  }

  return { render, navigate, setActive, onNavigate };
})();
