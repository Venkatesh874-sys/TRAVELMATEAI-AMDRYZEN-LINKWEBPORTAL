/* ============================================================
   TRAVELMATE AI — HELPER UTILITIES
   js/utils/helpers.js
   ============================================================ */

const Helpers = (() => {

  /** Create an element with optional classes, attributes, and innerHTML */
  function el(tag, opts = {}) {
    const elem = document.createElement(tag);
    if (opts.className) elem.className = opts.className;
    if (opts.id)        elem.id = opts.id;
    if (opts.html)      elem.innerHTML = opts.html;
    if (opts.text)      elem.textContent = opts.text;
    if (opts.attrs) Object.entries(opts.attrs).forEach(([k, v]) => elem.setAttribute(k, v));
    if (opts.styles)  Object.assign(elem.style, opts.styles);
    if (opts.on)      Object.entries(opts.on).forEach(([k, v]) => elem.addEventListener(k, v));
    return elem;
  }

  /** Safely query selector from parent or document */
  function qs(selector, parent = document) {
    return parent.querySelector(selector);
  }

  /** Safely query selector all */
  function qsa(selector, parent = document) {
    return [...parent.querySelectorAll(selector)];
  }

  /** Show spinner markup */
  function spinnerHTML(cls = '') {
    return `<span class="spinner ${cls}"></span>`;
  }

  /** Copy text to clipboard with visual feedback on a button */
  async function copyToClipboard(text, btn) {
    try {
      await navigator.clipboard.writeText(text);
      if (btn) {
        const orig = btn.innerHTML;
        btn.innerHTML = `${Icons.get('check', 14, 'var(--accent)')} Copied!`;
        setTimeout(() => { btn.innerHTML = orig; }, 2000);
      }
    } catch (_) { /* clipboard not available */ }
  }

  /** Toast notification */
  function toast(message, type = 'info') {
    const colors = { info: 'var(--accent)', danger: 'var(--danger)', success: 'var(--success)' };
    const t = el('div', {
      className: 'fade-in',
      html: message,
      styles: {
        position: 'fixed',
        bottom: 'calc(var(--nav-height) + 16px)',
        left: '50%',
        transform: 'translateX(-50%)',
        background: 'var(--surface)',
        border: `1px solid ${colors[type]}`,
        color: colors[type],
        padding: '10px 20px',
        borderRadius: 'var(--radius-md)',
        fontSize: '13px',
        fontWeight: '500',
        zIndex: '9998',
        whiteSpace: 'nowrap',
        boxShadow: 'var(--shadow)',
      }
    });
    document.body.appendChild(t);
    setTimeout(() => t.remove(), 3000);
  }

  /** Format result text as styled HTML paragraphs */
  function formatAIText(text) {
    if (!text) return '';
    // Escape HTML
    const escaped = text
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');
    // Convert **bold** to <strong>
    const bolded = escaped.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
    // Convert line breaks
    return bolded.split('\n').map(line => {
      if (!line.trim()) return '<br>';
      return `<span>${line}</span><br>`;
    }).join('');
  }

  /** Animate a number from 0 to target */
  function animateNumber(el, target, duration = 1000) {
    let start = null;
    const step = (timestamp) => {
      if (!start) start = timestamp;
      const progress = Math.min((timestamp - start) / duration, 1);
      el.textContent = Math.floor(progress * target);
      if (progress < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  }

  /** LocalStorage helpers */
  const store = {
    get: (key) => { try { return JSON.parse(localStorage.getItem(key)); } catch { return null; } },
    set: (key, val) => { try { localStorage.setItem(key, JSON.stringify(val)); } catch { } },
    remove: (key) => { try { localStorage.removeItem(key); } catch { } },
  };

  return { el, qs, qsa, spinnerHTML, copyToClipboard, toast, formatAIText, animateNumber, store };
})();
