/* ============================================================
   TRAVELMATE AI — PAYMENT ADVISOR PAGE
   js/pages/payment.js
   ============================================================ */

const PaymentPage = (() => {

  const QUICK_DESTINATIONS = [
    'India', 'Japan', 'Bali, Indonesia', 'Thailand', 'France', 'USA', 'UAE', 'Singapore'
  ];

  let isLoading = false;

  function render() {
    const wrapper = Helpers.el('div', { className: 'page-wrapper page-enter' });

    wrapper.innerHTML = `
      <div class="section-title">Payment Advisor</div>
      <div class="section-subtitle">Know exactly how to pay anywhere in the world</div>

      <div class="card p-lg mb-lg">
        <div class="form-group mb-md">
          <label class="form-label">Destination</label>
          <input class="input" id="payment-dest" placeholder="Enter country or city..." />
        </div>

        <!-- Quick Destinations -->
        <div class="quick-dest-bar mb-lg" id="quick-dest-bar"></div>

        <button class="btn btn-primary btn--full" id="payment-btn" style="padding:13px;">
          ${Icons.get('dollar', 18)} Get Payment Advice
        </button>
      </div>

      <!-- Result -->
      <div id="payment-result" class="hidden"></div>
    `;

    _renderQuickDests(Helpers.qs('#quick-dest-bar', wrapper), wrapper);
    Helpers.qs('#payment-btn', wrapper).addEventListener('click', () => _advise(wrapper));
    Helpers.qs('#payment-dest', wrapper).addEventListener('keydown', e => {
      if (e.key === 'Enter') _advise(wrapper);
    });

    return wrapper;
  }

  function _renderQuickDests(container, wrapper) {
    QUICK_DESTINATIONS.forEach(dest => {
      const chip = Helpers.el('span', {
        className: 'tag',
        text: dest,
        on: {
          click: () => {
            Helpers.qs('#payment-dest', wrapper).value = dest;
            _advise(wrapper);
          }
        }
      });
      container.appendChild(chip);
    });
  }

  async function _advise(wrapper) {
    if (isLoading) return;

    const dest = Helpers.qs('#payment-dest', wrapper).value.trim();
    if (!dest) {
      Helpers.toast('Please enter a destination!', 'danger');
      Helpers.qs('#payment-dest', wrapper).focus();
      return;
    }

    isLoading = true;
    const btn = Helpers.qs('#payment-btn', wrapper);
    btn.disabled = true;
    btn.innerHTML = `${Helpers.spinnerHTML('spinner--dark')} Analyzing...`;

    const resultBox = Helpers.qs('#payment-result', wrapper);
    resultBox.classList.remove('hidden');
    resultBox.innerHTML = `
      <div class="result-box">
        <div class="result-box__header">
          <div class="result-box__title">
            ${Icons.get('dollar', 18, 'var(--success)')} Payment Guide: ${dest}
          </div>
          <button class="btn btn-ghost" id="copy-payment" style="padding:6px 12px;font-size:12px;">
            ${Icons.get('copy', 14)} Copy
          </button>
        </div>
        <div id="payment-content" class="typing-cursor" style="line-height:1.8;font-size:14px;">Analyzing payment landscape...</div>
      </div>
    `;

    const contentEl = Helpers.qs('#payment-content', resultBox);

    const prompt = `You are a travel finance expert. Provide comprehensive payment and money advice for tourists visiting ${dest}.

Structure your response with these sections:

💱 LOCAL CURRENCY
- Currency name, symbol, and ISO code
- Current approximate exchange rates vs USD, EUR, GBP
- Best places to exchange currency

💳 CARD ACCEPTANCE
- Which international cards work (Visa/Mastercard/Amex)
- Where cards are accepted (restaurants, hotels, local markets)
- Any common card issues travelers face

📱 DIGITAL & MOBILE PAYMENTS
- UPI availability (especially for India)
- Apple Pay / Google Pay / Samsung Pay support
- Local payment apps tourists should know
- QR code payment usage

💵 CASH STRATEGY
- Is cash king here, or cards preferred?
- Recommended amount of cash to carry daily
- Denominations to keep handy
- Tips for small purchases

🏧 ATM TIPS
- Best ATM networks to use
- Typical ATM fees
- Safety tips at ATMs
- Withdrawal limits

💰 PRICE BENCHMARKS
- Budget meal: [price range]
- Mid-range restaurant: [price range]
- Street food / snacks: [price]
- Local taxi / ride per km: [price]
- Hotel budget / mid / luxury: [price ranges]
- Museum or attraction entry: [typical range]

⚠️ SCAM WARNINGS
- Most common money scams targeting tourists
- Taxi / transport scams
- Currency exchange scams
- How to avoid them

💡 PRO MONEY TIPS
- Best insider advice for saving money
- When to negotiate prices
- Tipping culture and norms

Be very specific, practical, and up-to-date. Use emojis for readability.`;

    try {
      let fullText = '';
      await API.callClaude(prompt, (text) => {
        fullText = text;
        contentEl.innerHTML = Helpers.formatAIText(text) + '<span class="typing-cursor"></span>';
      });

      contentEl.innerHTML = Helpers.formatAIText(fullText);

      const copyBtn = Helpers.qs('#copy-payment', resultBox);
      copyBtn.addEventListener('click', () => Helpers.copyToClipboard(fullText, copyBtn));

    } catch (err) {
      contentEl.innerHTML = `<div class="alert alert--danger">${Icons.get('alert', 16, 'var(--danger)')} ${err.message}</div>`;
    }

    isLoading = false;
    btn.disabled = false;
    btn.innerHTML = `${Icons.get('dollar', 18)} Get Payment Advice`;
    resultBox.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  return { render };
})();
