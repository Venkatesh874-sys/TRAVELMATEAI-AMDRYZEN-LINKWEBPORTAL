/* ============================================================
   TRAVELMATE AI — PROFILE PAGE
   js/pages/profile.js
   ============================================================ */

const ProfilePage = (() => {

  let isEditing = false;
  let onUserUpdateCallback = null;

  function render(user, onUserUpdate) {
    onUserUpdateCallback = onUserUpdate;
    const wrapper = Helpers.el('div', { className: 'page-wrapper page-enter' });
    _build(wrapper, user);
    return wrapper;
  }

  function _build(wrapper, user) {
    wrapper.innerHTML = `
      <div class="section-title">Profile</div>
      <div class="section-subtitle">Your travel identity & preferences</div>

      <!-- Avatar Card -->
      <div class="card p-lg mb-lg" style="text-align:center;">
        <div class="profile-avatar">✈️</div>
        <div class="profile-name">${user.name}</div>
        <div class="profile-email">${user.email}</div>
        <div class="profile-tags">
          <span class="tag">🌍 ${user.country}</span>
          <span class="tag">${user.style || 'Adventure Seeker'}</span>
        </div>
      </div>

      <!-- Preferences Card -->
      <div class="card p-lg mb-lg">
        <div class="flex justify-between items-center mb-md">
          <div class="font-display font-bold" style="font-size:16px;">Travel Preferences</div>
          <button class="btn btn-ghost" id="edit-toggle" style="padding:7px 16px;font-size:13px;">
            ${Icons.get('edit', 14)} Edit
          </button>
        </div>

        <!-- View Mode -->
        <div id="profile-view">
          ${[
            ['Name',         user.name],
            ['Email',        user.email],
            ['Home Country', user.country],
            ['Travel Style', user.style || 'Adventure Seeker'],
            ['Member Since', user.joinedAt || 'Today'],
          ].map(([k, v]) => `
            <div class="profile-field">
              <span class="profile-field__key">${k}</span>
              <span>${v}</span>
            </div>
          `).join('')}
        </div>

        <!-- Edit Mode (hidden) -->
        <div id="profile-edit" class="hidden" style="display:grid;gap:12px;">
          <div class="form-group">
            <label class="form-label">Name</label>
            <input class="input" id="edit-name" value="${user.name}" />
          </div>
          <div class="form-group">
            <label class="form-label">Home Country</label>
            <input class="input" id="edit-country" value="${user.country}" />
          </div>
          <div class="form-group">
            <label class="form-label">Travel Style</label>
            <select class="input" id="edit-style">
              ${['Budget Backpacker','Luxury Traveler','Adventure Seeker','Cultural Explorer','Content Creator','Digital Nomad']
                .map(s => `<option ${s === (user.style || 'Adventure Seeker') ? 'selected' : ''}>${s}</option>`).join('')}
            </select>
          </div>
          <button class="btn btn-primary" id="save-profile">
            ${Icons.get('check', 16)} Save Changes
          </button>
        </div>
      </div>

      <!-- Stats -->
      <div class="card p-lg mb-lg">
        <div class="font-display font-bold mb-md" style="font-size:16px;">Travel Stats</div>
        <div class="grid-3" style="gap:12px;" id="profile-stats"></div>
      </div>

      <!-- Preferences -->
      <div class="card p-lg mb-lg">
        <div class="font-display font-bold mb-md" style="font-size:16px;">Travel Interests</div>
        <div style="display:flex;flex-wrap:wrap;gap:8px;" id="interest-chips"></div>
      </div>

      <!-- Danger Zone -->
      <div class="card p-lg" style="border-color:rgba(255,71,87,0.2);">
        <div class="font-display font-bold mb-md" style="font-size:16px;color:var(--danger);">Account</div>
        <button class="btn btn-danger" id="logout-btn" style="width:100%;justify-content:center;">
          Sign Out
        </button>
      </div>
    `;

    _renderStats(Helpers.qs('#profile-stats', wrapper));
    _renderInterests(Helpers.qs('#interest-chips', wrapper));
    _wireEditMode(wrapper, user);
    _wireLogout(wrapper);
  }

  function _renderStats(container) {
    [['🗺️', '12', 'Trips'], ['🌍', '8', 'Countries'], ['⭐', '47', 'Reviews'], ['💾', '93', 'Saved'], ['🌐', '24', 'Languages'], ['📸', '156', 'Photos']].forEach(([e, n, l]) => {
      const card = Helpers.el('div', {
        className: 'stat-mini',
        html: `
          <div class="stat-mini__emoji">${e}</div>
          <div class="stat-mini__value" data-target="${n}">0</div>
          <div class="stat-mini__label">${l}</div>
        `
      });
      container.appendChild(card);
      const numEl = card.querySelector('.stat-mini__value');
      setTimeout(() => Helpers.animateNumber(numEl, parseInt(n), 800), 200);
    });
  }

  function _renderInterests(container) {
    const interests = [
      '🍜 Food', '📸 Photography', '🏔️ Adventure', '🌿 Nature',
      '🛕 Culture', '🏖️ Beaches', '🌙 Nightlife', '🎭 Arts'
    ];
    interests.forEach(i => {
      container.appendChild(Helpers.el('span', { className: 'tag active', text: i }));
    });
  }

  function _wireEditMode(wrapper, user) {
    const editToggle = Helpers.qs('#edit-toggle', wrapper);
    const viewEl     = Helpers.qs('#profile-view', wrapper);
    const editEl     = Helpers.qs('#profile-edit', wrapper);

    editToggle.addEventListener('click', () => {
      isEditing = !isEditing;
      if (isEditing) {
        viewEl.classList.add('hidden');
        editEl.classList.remove('hidden');
        editEl.style.display = 'grid';
        editToggle.innerHTML = `${Icons.get('close', 14)} Cancel`;
      } else {
        viewEl.classList.remove('hidden');
        editEl.classList.add('hidden');
        editEl.style.display = 'none';
        editToggle.innerHTML = `${Icons.get('edit', 14)} Edit`;
      }
    });

    const saveBtn = Helpers.qs('#save-profile', wrapper);
    if (saveBtn) {
      saveBtn.addEventListener('click', () => {
        const updatedUser = {
          ...user,
          name:    Helpers.qs('#edit-name',    wrapper)?.value?.trim() || user.name,
          country: Helpers.qs('#edit-country', wrapper)?.value?.trim() || user.country,
          style:   Helpers.qs('#edit-style',   wrapper)?.value         || user.style,
        };

        Helpers.store.set('travelmate_user', updatedUser);
        if (typeof onUserUpdateCallback === 'function') onUserUpdateCallback(updatedUser);

        Helpers.toast('Profile updated!', 'success');
        // Rebuild with new data
        _build(wrapper, updatedUser);
      });
    }
  }

  function _wireLogout(wrapper) {
    Helpers.qs('#logout-btn', wrapper)?.addEventListener('click', () => {
      Helpers.store.remove('travelmate_user');
      window.location.reload();
    });
  }

  return { render };
})();
