/* ============================================================
   TRAVELMATE AI — AUTH PAGE (Login / Signup)
   js/pages/auth.js
   ============================================================ */

const AuthPage = (() => {

  let isLogin = true;
  let onAuthCallback = null;
  let container = null;

  function render(onAuth) {
    onAuthCallback = onAuth;
    container = Helpers.el('div', { className: 'auth-wrapper' });
    _build();
    return container;
  }

  function _build() {
    container.innerHTML = '';

    const card = Helpers.el('div', {
      className: 'auth-card scale-in',
      html: `
        <div style="text-align:center;margin-bottom:32px;">
          <div class="auth-card__logo float-anim">✈️</div>
          <div class="auth-card__title">TravelMate AI</div>
          <div class="auth-card__sub">${isLogin ? 'Welcome back, explorer' : 'Start your journey today'}</div>
        </div>

        <div style="display:grid;gap:12px;margin-bottom:20px;" id="auth-fields">
          ${!isLogin ? `<input class="input" id="auth-name" placeholder="Your full name" type="text" />` : ''}
          <input class="input" id="auth-email" placeholder="Email address" type="email" value="demo@travelmate.ai" />
          <input class="input" id="auth-password" placeholder="Password" type="password" value="demo123" />
          ${!isLogin ? `<input class="input" id="auth-country" placeholder="Your home country" type="text" value="India" />` : ''}
        </div>

        <button class="btn btn-primary btn--full" id="auth-submit" style="padding:14px;font-size:15px;">
          ${isLogin ? 'Sign In' : 'Create Account'}
        </button>

        <div style="text-align:center;margin-top:16px;font-size:14px;color:var(--muted);">
          ${isLogin ? "New to TravelMate?" : 'Already have an account?'}
          <span id="auth-toggle" style="color:var(--accent);cursor:pointer;margin-left:4px;">
            ${isLogin ? 'Sign up' : 'Sign in'}
          </span>
        </div>

        <div class="alert alert--info" style="margin-top:20px;font-size:12px;">
          ${Icons.get('sparkles', 13, 'var(--accent)')}
          <span>Demo credentials pre-filled — just click Sign In!</span>
        </div>
      `
    });

    container.appendChild(card);

    // Wire events
    document.getElementById('auth-submit').addEventListener('click', _handleSubmit);
    document.getElementById('auth-toggle').addEventListener('click', _toggleMode);

    // Enter key support
    card.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') _handleSubmit();
    });
  }

  function _handleSubmit() {
    const email    = document.getElementById('auth-email')?.value?.trim();
    const password = document.getElementById('auth-password')?.value?.trim();
    const name     = document.getElementById('auth-name')?.value?.trim();
    const country  = document.getElementById('auth-country')?.value?.trim();

    if (!email || !password) {
      Helpers.toast('Please fill in all required fields', 'danger');
      return;
    }

    const userData = {
      name:    name || 'Alex Chen',
      email:   email,
      country: country || 'India',
      style:   'Adventure Seeker',
      joinedAt: new Date().toLocaleDateString(),
    };

    Helpers.store.set('travelmate_user', userData);
    if (typeof onAuthCallback === 'function') onAuthCallback(userData);
  }

  function _toggleMode() {
    isLogin = !isLogin;
    _build();
  }

  return { render };
})();
