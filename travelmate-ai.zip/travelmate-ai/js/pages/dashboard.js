/* ============================================================
   TRAVELMATE AI — DASHBOARD PAGE
   js/pages/dashboard.js
   ============================================================ */

const DashboardPage = (() => {

  function render(user, onNav) {
    const wrapper = Helpers.el('div', { className: 'page-wrapper page-enter' });

    wrapper.innerHTML = `
      <!-- Greeting -->
      <div class="mb-lg">
        <div class="dashboard-greeting">Good to see you,</div>
        <div class="section-title">${user.name} ✈️</div>
      </div>

      <!-- Stats -->
      <div class="grid-2 mb-xl" id="stats-grid"></div>

      <!-- Quick Actions -->
      <div class="mb-xl">
        <div class="font-display font-bold mb-md" style="font-size:16px;">Quick Actions</div>
        <div class="grid-2" id="quick-actions" style="gap:12px;"></div>
      </div>

      <!-- Recent Activity -->
      <div class="card p-lg">
        <div class="font-display font-bold mb-md" style="font-size:16px;">Recent Activity</div>
        <div id="activity-list"></div>
      </div>
    `;

    _renderStats(Helpers.qs('#stats-grid', wrapper));
    _renderQuickActions(Helpers.qs('#quick-actions', wrapper), onNav);
    _renderActivity(Helpers.qs('#activity-list', wrapper));

    return wrapper;
  }

  function _renderStats(container) {
    const stats = [
      { label: 'Trips Planned',  value: 12, icon: 'map',       color: 'var(--accent)'  },
      { label: 'Countries',      value: 8,  icon: 'globe',     color: 'var(--accent3)' },
      { label: 'Translations',   value: 47, icon: 'translate', color: 'var(--accent2)' },
      { label: 'Saved Spots',    value: 93, icon: 'heart',     color: 'var(--danger)'  },
    ];

    stats.forEach((s, i) => {
      const card = Helpers.el('div', {
        className: `stat-card fade-up delay-${i}`,
        html: `
          <div class="flex justify-between items-center">
            <div>
              <div class="stat-card__value" style="color:${s.color};" data-target="${s.value}">0</div>
              <div class="stat-card__label">${s.label}</div>
            </div>
            <div class="stat-card__icon" style="background:${s.color}18;">
              ${Icons.get(s.icon, 22, s.color)}
            </div>
          </div>
        `
      });
      container.appendChild(card);

      // Animate counter
      const numEl = card.querySelector('.stat-card__value');
      setTimeout(() => Helpers.animateNumber(numEl, s.value, 800), i * 100);
    });
  }

  function _renderQuickActions(container, onNav) {
    const actions = [
      { label: 'Plan a Trip',  icon: 'compass',   page: 'planner',    color: 'var(--accent)'  },
      { label: 'Translate',    icon: 'translate', page: 'translator', color: 'var(--accent3)' },
      { label: 'Discover',     icon: 'star',      page: 'discover',   color: 'var(--gold)'    },
      { label: 'Creator',      icon: 'camera',    page: 'creator',    color: 'var(--accent2)' },
    ];

    actions.forEach((a, i) => {
      const btn = Helpers.el('button', {
        className: `quick-action-btn fade-up delay-${i}`,
        styles: {
          background: `${a.color}08`,
          borderColor: `${a.color}22`,
        },
        html: `
          <div style="width:36px;height:36px;border-radius:10px;background:${a.color}18;display:flex;align-items:center;justify-content:center;flex-shrink:0;">
            ${Icons.get(a.icon, 18, a.color)}
          </div>
          <span>${a.label}</span>
          ${Icons.get('arrow', 14, 'var(--muted)')}
        `,
        on: { click: () => onNav(a.page) }
      });
      container.appendChild(btn);
    });
  }

  function _renderActivity(container) {
    const activities = [
      { icon: '📍', text: 'Planned 7-day trip to Kyoto, Japan', time: '2h ago' },
      { icon: '🌐', text: 'Translated "Where is the station?" to Japanese', time: '5h ago' },
      { icon: '📸', text: 'Generated captions for Bali sunset photos', time: '1d ago' },
      { icon: '💰', text: 'Checked payment guide for Thailand', time: '2d ago' },
    ];

    activities.forEach((item, i) => {
      const row = Helpers.el('div', {
        className: `activity-item fade-up delay-${i}`,
        html: `
          <span class="activity-item__icon">${item.icon}</span>
          <span class="activity-item__text">${item.text}</span>
          <span class="activity-item__time">${item.time}</span>
        `
      });
      container.appendChild(row);
    });
  }

  return { render };
})();
