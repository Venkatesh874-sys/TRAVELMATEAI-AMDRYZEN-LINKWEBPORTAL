/* ============================================================
   TRAVELMATE AI — TRANSLATOR PAGE
   js/pages/translator.js
   ============================================================ */

const TranslatorPage = (() => {

  const LANGUAGES = {
    en: '🇬🇧 English',
    hi: '🇮🇳 Hindi',
    te: '🇮🇳 Telugu',
    es: '🇪🇸 Spanish',
    ja: '🇯🇵 Japanese',
    fr: '🇫🇷 French',
    zh: '🇨🇳 Chinese',
    ar: '🇸🇦 Arabic',
    de: '🇩🇪 German',
    ko: '🇰🇷 Korean',
  };

  const TRAVELER_PHRASES = [
    'Where is the nearest hospital?',
    'How much does this cost?',
    'I need help, please.',
    'Do you accept credit cards?',
    'Where is the bathroom?',
    'Can you call me a taxi?',
    'I am lost. Can you help?',
    'Thank you very much.',
    'Do you speak English?',
    'Can I have the menu please?',
    'Where is the nearest ATM?',
    'I am allergic to nuts.',
  ];

  let fromLang = 'en';
  let toLang   = 'ja';
  let mode     = 'custom'; // 'custom' | 'phrases'
  let isLoading = false;

  function render() {
    const wrapper = Helpers.el('div', { className: 'page-wrapper page-enter' });

    wrapper.innerHTML = `
      <div class="section-title">AI Translator</div>
      <div class="section-subtitle">Break language barriers in real-time</div>

      <!-- Language Selector -->
      <div class="flex items-center gap-sm mb-md">
        <select class="input" id="lang-from">
          ${Object.entries(LANGUAGES).map(([k,v]) => `<option value="${k}"${k===fromLang?' selected':''}>${v}</option>`).join('')}
        </select>
        <button class="lang-swap-btn" id="lang-swap" title="Swap languages">⇄</button>
        <select class="input" id="lang-to">
          ${Object.entries(LANGUAGES).map(([k,v]) => `<option value="${k}"${k===toLang?' selected':''}>${v}</option>`).join('')}
        </select>
      </div>

      <!-- Mode Tabs -->
      <div class="flex gap-sm mb-md flex-wrap">
        <button class="tag active" id="tab-custom">✍️ Custom Text</button>
        <button class="tag" id="tab-phrases">📋 Traveler Phrases</button>
      </div>

      <!-- Custom Input -->
      <div id="custom-panel">
        <div class="form-group mb-md">
          <textarea class="input" id="translate-input" placeholder="Type or paste text to translate..." style="min-height:120px;"></textarea>
        </div>
        <button class="btn btn-primary btn--full mb-lg" id="translate-btn" style="padding:13px;">
          ${Icons.get('globe', 18)} Translate
        </button>
      </div>

      <!-- Phrases Panel -->
      <div id="phrases-panel" class="card p-lg mb-lg hidden">
        <div class="font-bold mb-md" style="font-size:14px;">Common Traveler Phrases — tap to translate</div>
        <div id="phrases-list" style="display:grid;gap:8px;"></div>
      </div>

      <!-- Result -->
      <div id="translate-result" class="hidden"></div>
    `;

    _renderPhrases(Helpers.qs('#phrases-list', wrapper));
    _wireEvents(wrapper);

    return wrapper;
  }

  function _renderPhrases(container) {
    TRAVELER_PHRASES.forEach(phrase => {
      const btn = Helpers.el('button', {
        className: 'phrase-btn',
        text: phrase,
        on: { click: () => _translatePhrase(phrase) }
      });
      container.appendChild(btn);
    });
  }

  function _wireEvents(wrapper) {
    // Lang selectors
    Helpers.qs('#lang-from', wrapper).addEventListener('change', e => { fromLang = e.target.value; });
    Helpers.qs('#lang-to',   wrapper).addEventListener('change', e => { toLang   = e.target.value; });

    // Swap button
    Helpers.qs('#lang-swap', wrapper).addEventListener('click', () => {
      const tmp = fromLang;
      fromLang  = toLang;
      toLang    = tmp;
      Helpers.qs('#lang-from', wrapper).value = fromLang;
      Helpers.qs('#lang-to',   wrapper).value = toLang;
    });

    // Mode tabs
    Helpers.qs('#tab-custom', wrapper).addEventListener('click', () => _setMode('custom', wrapper));
    Helpers.qs('#tab-phrases', wrapper).addEventListener('click', () => _setMode('phrases', wrapper));

    // Translate button
    Helpers.qs('#translate-btn', wrapper).addEventListener('click', () => {
      const text = Helpers.qs('#translate-input', wrapper).value.trim();
      if (text) _runTranslation(text, wrapper);
    });

    // Enter key
    Helpers.qs('#translate-input', wrapper).addEventListener('keydown', e => {
      if (e.key === 'Enter' && e.ctrlKey) {
        const text = e.target.value.trim();
        if (text) _runTranslation(text, wrapper);
      }
    });
  }

  function _setMode(newMode, wrapper) {
    mode = newMode;
    const customPanel  = Helpers.qs('#custom-panel',  wrapper);
    const phrasesPanel = Helpers.qs('#phrases-panel', wrapper);
    const tabCustom    = Helpers.qs('#tab-custom',    wrapper);
    const tabPhrases   = Helpers.qs('#tab-phrases',   wrapper);

    if (newMode === 'custom') {
      customPanel.classList.remove('hidden');
      phrasesPanel.classList.add('hidden');
      tabCustom.classList.add('active');
      tabPhrases.classList.remove('active');
    } else {
      customPanel.classList.add('hidden');
      phrasesPanel.classList.remove('hidden');
      tabPhrases.classList.add('active');
      tabCustom.classList.remove('active');
    }
  }

  function _translatePhrase(phrase) {
    _runTranslation(phrase, document.querySelector('.page-wrapper'));
  }

  async function _runTranslation(text, wrapper) {
    if (isLoading || !text) return;
    isLoading = true;

    const fromLabel = LANGUAGES[fromLang];
    const toLabel   = LANGUAGES[toLang];

    const resultBox = Helpers.qs('#translate-result', wrapper);
    resultBox.classList.remove('hidden');
    resultBox.innerHTML = `
      <div class="result-box">
        <div class="result-box__header">
          <div class="result-box__title">
            ${Icons.get('translate', 18, 'var(--accent3)')} Translation
          </div>
          <div class="flex gap-sm">
            <span class="badge badge--accent">${fromLabel} → ${toLabel}</span>
            <button class="btn btn-ghost" id="copy-translation" style="padding:6px 12px;font-size:12px;">
              ${Icons.get('copy', 14)} Copy
            </button>
          </div>
        </div>
        <div id="translation-content" class="typing-cursor" style="line-height:1.8;font-size:14px;">Translating...</div>
      </div>
    `;

    const contentEl = Helpers.qs('#translation-content', resultBox);

    const prompt = `Translate the following text from ${fromLabel} to ${toLabel}.

Original text: "${text}"

Provide your response in this exact format:

📝 TRANSLATION:
[The complete translation here]

🔊 PRONUNCIATION:
[Romanized pronunciation guide — only if the target language uses non-Latin script, otherwise skip this section]

🎯 NATURAL ALTERNATIVE:
[A more colloquial/natural way locals would say it, if different from the direct translation]

💡 CULTURAL NOTE:
[One brief, practical cultural tip relevant to this phrase for travelers — keep to 1-2 sentences]

Be accurate and natural. Optimize for a traveler being understood by locals.`;

    try {
      let fullText = '';
      await API.callClaude(prompt, (text) => {
        fullText = text;
        contentEl.classList.remove('typing-cursor');
        contentEl.innerHTML = Helpers.formatAIText(text) + '<span class="typing-cursor"></span>';
      });

      contentEl.innerHTML = Helpers.formatAIText(fullText);

      // Copy button
      const copyBtn = Helpers.qs('#copy-translation', resultBox);
      copyBtn.addEventListener('click', () => Helpers.copyToClipboard(fullText, copyBtn));

    } catch (err) {
      contentEl.innerHTML = `<div class="alert alert--danger">${Icons.get('alert', 16, 'var(--danger)')} ${err.message}</div>`;
    }

    isLoading = false;
    resultBox.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  return { render };
})();
