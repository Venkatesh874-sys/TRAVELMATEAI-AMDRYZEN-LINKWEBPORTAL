/* ============================================================
   TRAVELMATE AI — TRIP PLANNER PAGE
   js/pages/planner.js
   ============================================================ */

const PlannerPage = (() => {

  const INTERESTS = [
    '🍜 Food', '🏔️ Adventure', '🛕 Temples', '🌙 Nightlife',
    '📸 Photography', '🏖️ Beaches', '🛍️ Shopping', '🎭 Culture', '🌿 Nature'
  ];

  let selectedInterests = [];
  let isLoading = false;

  function render() {
    const wrapper = Helpers.el('div', { className: 'page-wrapper page-enter' });

    wrapper.innerHTML = `
      <div class="section-title">AI Trip Planner</div>
      <div class="section-subtitle">Tell us your dream trip — AI handles the rest</div>

      <!-- Form Card -->
      <div class="card p-lg mb-lg">
        <!-- Destination -->
        <div class="form-group mb-md">
          <label class="form-label">Destination *</label>
          <input class="input" id="plan-destination" placeholder="e.g. Kyoto Japan · Bali Indonesia · Paris France" />
        </div>

        <!-- Days & Budget Row -->
        <div class="grid-2 mb-md">
          <div class="form-group">
            <label class="form-label">Number of Days</label>
            <select class="input" id="plan-days">
              ${[1,2,3,4,5,7,10,14].map(d => `<option value="${d}"${d===5?' selected':''}>${d} day${d>1?'s':''}</option>`).join('')}
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">Total Budget</label>
            <div class="flex gap-sm">
              <select class="input" id="plan-currency" style="width:80px;flex-shrink:0;">
                ${['USD','EUR','GBP','INR','JPY','AUD','SGD'].map(c=>`<option>${c}</option>`).join('')}
              </select>
              <input class="input" id="plan-budget" type="number" placeholder="1000" value="1000" />
            </div>
          </div>
        </div>

        <!-- Interests -->
        <div class="form-group mb-lg">
          <label class="form-label">Your Interests <span style="color:var(--muted)">(select all that apply)</span></label>
          <div class="interests-grid" id="interests-container"></div>
        </div>

        <!-- Generate Button -->
        <button class="btn btn-primary btn--full" id="plan-generate" style="padding:14px;font-size:15px;">
          ${Icons.get('sparkles', 18)} Generate AI Itinerary
        </button>
      </div>

      <!-- Result -->
      <div id="plan-result" class="hidden"></div>
    `;

    _renderInterests(Helpers.qs('#interests-container', wrapper));
    Helpers.qs('#plan-generate', wrapper).addEventListener('click', () => _generate(wrapper));

    // Allow Enter to trigger
    Helpers.qs('#plan-destination', wrapper).addEventListener('keydown', (e) => {
      if (e.key === 'Enter') _generate(wrapper);
    });

    return wrapper;
  }

  function _renderInterests(container) {
    INTERESTS.forEach(interest => {
      const chip = Helpers.el('span', {
        className: 'tag',
        text: interest,
        on: {
          click: () => {
            const idx = selectedInterests.indexOf(interest);
            if (idx >= 0) {
              selectedInterests.splice(idx, 1);
              chip.classList.remove('active');
            } else {
              selectedInterests.push(interest);
              chip.classList.add('active');
            }
          }
        }
      });
      container.appendChild(chip);
    });
  }

  async function _generate(wrapper) {
    if (isLoading) return;

    const dest     = Helpers.qs('#plan-destination', wrapper).value.trim();
    const days     = Helpers.qs('#plan-days', wrapper).value;
    const budget   = Helpers.qs('#plan-budget', wrapper).value;
    const currency = Helpers.qs('#plan-currency', wrapper).value;

    if (!dest) {
      Helpers.toast('Please enter a destination!', 'danger');
      Helpers.qs('#plan-destination', wrapper).focus();
      return;
    }

    isLoading = true;
    const btn = Helpers.qs('#plan-generate', wrapper);
    btn.disabled = true;
    btn.innerHTML = `${Helpers.spinnerHTML('spinner--dark')} Generating Itinerary...`;

    const resultBox = Helpers.qs('#plan-result', wrapper);
    resultBox.classList.remove('hidden');
    resultBox.innerHTML = `
      <div class="result-box">
        <div class="result-box__header">
          <div class="result-box__title">${Icons.get('map', 18, 'var(--accent)')} Your AI Itinerary</div>
          <button class="btn btn-ghost" id="copy-itinerary" style="padding:6px 12px;font-size:12px;">
            ${Icons.get('copy', 14)} Copy
          </button>
        </div>
        <div id="itinerary-content" class="itinerary-result typing-cursor">Generating your perfect trip...</div>
      </div>
    `;

    const contentEl = Helpers.qs('#itinerary-content', resultBox);

    const prompt = `You are TravelMate AI, an expert travel planner. Create a detailed ${days}-day itinerary for ${dest} with a total budget of ${currency} ${budget}.

Traveler interests: ${selectedInterests.length ? selectedInterests.join(', ') : 'General sightseeing, culture, food'}

Please provide a complete travel plan with:

🗓️ DAY-BY-DAY ITINERARY
For each day include:
- Morning activities (with specific place names)
- Afternoon activities  
- Evening activities
- Estimated costs per activity

💰 BUDGET BREAKDOWN
- Accommodation (per night estimate)
- Food & dining
- Transport & local travel
- Activities & entrance fees
- Shopping & misc
- Total estimated cost

🌤️ BEST VISITING TIPS
- Best time of day for key attractions
- Avoid the crowds tips
- Local transport options

💡 LOCAL TIPS & CULTURE
- Cultural etiquette
- Must-try local foods
- Language basics
- Safety notes

Be specific, practical, and use emojis for easy reading. Include actual place names, not generic descriptions.`;

    try {
      let fullText = '';
      await API.callClaude(prompt, (text) => {
        fullText = text;
        contentEl.classList.remove('typing-cursor');
        contentEl.innerHTML = Helpers.formatAIText(text) + '<span class="typing-cursor"></span>';
      });

      // Final render without cursor
      contentEl.classList.remove('typing-cursor');
      contentEl.innerHTML = Helpers.formatAIText(fullText);

      // Wire copy button
      const copyBtn = Helpers.qs('#copy-itinerary', resultBox);
      copyBtn.addEventListener('click', () => Helpers.copyToClipboard(fullText, copyBtn));

      Helpers.toast('Itinerary generated!', 'success');
    } catch (err) {
      contentEl.innerHTML = `<div class="alert alert--danger">${Icons.get('alert', 16, 'var(--danger)')} Error: ${err.message}</div>`;
    }

    isLoading = false;
    btn.disabled = false;
    btn.innerHTML = `${Icons.get('sparkles', 18)} Generate AI Itinerary`;

    // Scroll to result
    resultBox.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  return { render };
})();
