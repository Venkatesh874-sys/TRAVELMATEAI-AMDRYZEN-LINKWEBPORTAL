/* ============================================================
   TRAVELMATE AI — DISCOVER PAGE
   js/pages/discover.js
   ============================================================ */

const DiscoverPage = (() => {

  const CATEGORIES = [
    { id: 'all',      label: '🌟 All'          },
    { id: 'food',     label: '🍜 Food & Cafés'  },
    { id: 'photo',    label: '📸 Photo Spots'   },
    { id: 'hidden',   label: '💎 Hidden Gems'   },
    { id: 'nightlife',label: '🌙 Nightlife'     },
    { id: 'nature',   label: '🌿 Nature'        },
    { id: 'culture',  label: '🎭 Culture'       },
    { id: 'luxury',   label: '✨ Luxury'        },
  ];

  let selectedCategory = 'all';
  let isLoading = false;

  function render() {
    const wrapper = Helpers.el('div', { className: 'page-wrapper page-enter' });

    wrapper.innerHTML = `
      <div class="section-title">Discover</div>
      <div class="section-subtitle">AI-curated spots picked just for you</div>

      <div class="card p-lg mb-lg">
        <!-- City Input -->
        <div class="form-group mb-md">
          <label class="form-label">Where do you want to explore?</label>
          <input class="input" id="discover-city" placeholder="e.g. Tokyo · Barcelona · Mumbai · New York" />
        </div>

        <!-- Category Filter -->
        <div class="category-bar mb-md" id="category-bar"></div>

        <!-- Discover Button -->
        <button class="btn btn-primary btn--full" id="discover-btn" style="padding:13px;">
          ${Icons.get('star', 18)} Discover Places
        </button>
      </div>

      <!-- Result -->
      <div id="discover-result" class="hidden"></div>
    `;

    _renderCategories(Helpers.qs('#category-bar', wrapper));
    Helpers.qs('#discover-btn', wrapper).addEventListener('click', () => _discover(wrapper));
    Helpers.qs('#discover-city', wrapper).addEventListener('keydown', e => {
      if (e.key === 'Enter') _discover(wrapper);
    });

    return wrapper;
  }

  function _renderCategories(container) {
    CATEGORIES.forEach(cat => {
      const chip = Helpers.el('span', {
        className: `tag ${cat.id === selectedCategory ? 'active' : ''}`,
        text: cat.label,
        on: {
          click: () => {
            selectedCategory = cat.id;
            container.querySelectorAll('.tag').forEach(t => t.classList.remove('active'));
            chip.classList.add('active');
          }
        }
      });
      container.appendChild(chip);
    });
  }

  async function _discover(wrapper) {
    if (isLoading) return;

    const city = Helpers.qs('#discover-city', wrapper).value.trim();
    if (!city) {
      Helpers.toast('Please enter a city to discover!', 'danger');
      Helpers.qs('#discover-city', wrapper).focus();
      return;
    }

    isLoading = true;
    const btn = Helpers.qs('#discover-btn', wrapper);
    btn.disabled = true;
    btn.innerHTML = `${Helpers.spinnerHTML('spinner--dark')} Discovering...`;

    const catLabel = CATEGORIES.find(c => c.id === selectedCategory)?.label || 'all types';

    const resultBox = Helpers.qs('#discover-result', wrapper);
    resultBox.classList.remove('hidden');
    resultBox.innerHTML = `
      <div class="result-box">
        <div class="result-box__header">
          <div class="result-box__title">
            ${Icons.get('pin', 18, 'var(--gold)')} Top Picks in ${city}
          </div>
          <button class="btn btn-ghost" id="copy-discover" style="padding:6px 12px;font-size:12px;">
            ${Icons.get('copy', 14)} Copy
          </button>
        </div>
        <div id="discover-content" class="typing-cursor" style="line-height:1.8;font-size:14px;">Finding the best spots...</div>
      </div>
    `;

    const contentEl = Helpers.qs('#discover-content', resultBox);

    const prompt = `You are a seasoned local travel expert for ${city}. Recommend the best spots in the category: ${catLabel}.

Provide 7-9 curated recommendations. For each spot include:

📍 [PLACE NAME] — [Neighborhood/Area]
⭐ Why it's special: [2-3 sentences explaining what makes this place unique]
💰 Price range: [Budget/Mid-range/Upscale + typical cost]
🕒 Best time: [Specific time of day, day of week, or season]
📸 Photo tip: [Best angle, lighting, or composition tip]
💡 Insider tip: [Something most tourists don't know]

---

Include a healthy mix of:
- 2-3 well-known must-sees (explained properly, not just listed)
- 3-4 under-the-radar hidden gems
- 1-2 unique/unusual spots

Be specific with real place names. Tailor recommendations to the category: ${catLabel}.`;

    try {
      let fullText = '';
      await API.callClaude(prompt, (text) => {
        fullText = text;
        contentEl.innerHTML = Helpers.formatAIText(text) + '<span class="typing-cursor"></span>';
      });

      contentEl.innerHTML = Helpers.formatAIText(fullText);

      const copyBtn = Helpers.qs('#copy-discover', resultBox);
      copyBtn.addEventListener('click', () => Helpers.copyToClipboard(fullText, copyBtn));

    } catch (err) {
      contentEl.innerHTML = `<div class="alert alert--danger">${Icons.get('alert', 16, 'var(--danger)')} ${err.message}</div>`;
    }

    isLoading = false;
    btn.disabled = false;
    btn.innerHTML = `${Icons.get('star', 18)} Discover Places`;
    resultBox.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  return { render };
})();
