/* ============================================================
   TRAVELMATE AI — CREATOR STUDIO PAGE
   js/pages/creator.js
   ============================================================ */

const CreatorPage = (() => {

  const MODES = [
    { id: 'caption',   label: '✍️ Caption',       placeholder: 'Describe your photo — e.g. "sunset at Santorini cliff, golden light, silhouette"' },
    { id: 'hashtag',   label: '# Hashtags',        placeholder: 'Your post topic and location — e.g. "street food photography in Bangkok"' },
    { id: 'reel',      label: '🎬 Reel Ideas',     placeholder: 'Destination + vibe — e.g. "solo travel in Tokyo, cinematic aesthetic"' },
    { id: 'golden',    label: '🌅 Golden Hour',    placeholder: 'City and approximate date — e.g. "Mumbai, March 15"' },
    { id: 'locations', label: '📍 Shoot Spots',    placeholder: 'City name — e.g. "Jaipur" or "Amsterdam"' },
  ];

  const PROMPTS = {
    caption: (input) => `You are a top travel content creator and social media expert.

Generate 5 distinct Instagram captions for this travel photo: "${input}"

Each caption must have a completely different style and tone:
1. 🌊 POETIC — evocative, lyrical, metaphorical
2. 😂 WITTY — clever, punny, light-hearted
3. 🔥 ADVENTURE — bold, inspiring, action-packed
4. 🤍 MINIMALIST — short, clean, powerful (under 10 words)
5. 📖 STORYTELLING — personal narrative, draw readers in

For each: provide the caption + 1 emoji (if appropriate) + word count.
Avoid generic travel clichés like "wanderlust" or "adventure awaits".`,

    hashtag: (input) => `You are a social media growth expert specializing in travel content.

Generate the ultimate hashtag strategy for: "${input}"

Organize into:

🔥 MEGA HASHTAGS (10M+ posts) — 5 tags
[These maximize reach but are competitive]

📈 MID-TIER HASHTAGS (500K–10M posts) — 10 tags
[Best balance of reach and discovery]

🎯 NICHE HASHTAGS (10K–500K posts) — 10 tags
[Higher engagement rate, targeted audience]

📍 LOCATION HASHTAGS — 5 tags
[Geo-specific for local discovery]

✨ COMMUNITY/AESTHETIC HASHTAGS — 5 tags
[Tribe-building and aesthetic fit]

Total: aim for 30-35 strategic tags. Explain briefly why the mid-tier and niche selections are optimal.`,

    reel: (input) => `You are a viral travel content strategist with 2M+ followers.

Create 5 creative short-form video/reel concepts for a travel creator: "${input}"

For each concept:
🎬 TITLE: [Catchy title]
⚡ HOOK (0-3 seconds): [The exact opening that stops scrolling]
📱 STRUCTURE: [Beat-by-beat content breakdown, 15-60 seconds]
🎵 AUDIO VIBE: [Song genre/mood, specific trending audio suggestions]
📊 FORMAT: [POV / Talking head / B-roll montage / Transition / Story-based]
🔥 VIRAL ANGLE: [What makes this shareable — emotion, surprise, utility]
💬 CTA: [What to tell viewers to do]

Make these genuinely creative and current. Reference current social media trends.`,

    golden: (input) => `You are a professional travel photographer specializing in golden hour photography.

Provide a complete golden hour guide for: "${input}"

📅 GOLDEN HOUR TIMING
- Today's approximate sunrise time (calculate from typical data)
- Golden hour window: [time range after sunrise]
- Sunset time (typical for this location/season)
- Blue hour window: [time range after sunset]
- Magic hour total duration

📍 TOP 5 GOLDEN HOUR LOCATIONS
For each: name, type, why it's perfect at golden hour, exact positioning tip

📷 CAMERA SETTINGS FOR GOLDEN LIGHT
- Aperture range suggestions
- ISO recommendations
- White balance tips
- Exposure compensation tricks
- Lens recommendations

🌤️ WEATHER & CONDITIONS
- What sky conditions create the best golden hour
- How to read weather apps for photographers
- Backup plans for overcast days (blue hour, moody shots)

📱 MOBILE PHOTOGRAPHY TIPS
- Best apps for calculating golden hour (Photopills, Sun Surveyor, etc.)
- Mobile camera settings
- Editing tips for golden tones`,

    locations: (input) => `You are a travel photography location scout who has photographed ${input} extensively.

List the TOP 10 photography locations in ${input} for travel content creators.

For each location:
📍 NAME & NEIGHBORHOOD
📷 TYPE: [Street / Architecture / Nature / People / Aerial / Night / Market / etc.]
⭐ WHAT MAKES IT ICONIC: [2 sentences]
🕒 BEST TIME: [Specific time window + why]
📐 COMPOSITION TIP: [Specific framing, angle, or technique]
📱 INSTAGRAM CAPTION IDEA: [Ready-to-use caption suggestion]
⚠️ DIFFICULTY: [Easy / Moderate / Advanced] + access notes
💰 ACCESS: [Free / Paid — include cost if applicable]

Mix of:
- 3 iconic/famous spots (but with specific tips most guides miss)
- 4 semi-hidden spots known by local creators
- 3 genuinely secret locations only locals know

Be specific. No generic advice.`,
  };

  let currentMode = 'caption';
  let isLoading = false;

  function render() {
    const wrapper = Helpers.el('div', { className: 'page-wrapper page-enter' });

    wrapper.innerHTML = `
      <div class="flex items-center gap-sm mb-md" style="flex-wrap:wrap;">
        <div class="section-title" style="margin-bottom:0;">Creator Studio</div>
        <span class="badge badge--pro">PRO</span>
      </div>
      <div class="section-subtitle">AI tools built exclusively for travel content creators</div>

      <!-- Mode Selector -->
      <div class="creator-modes" id="mode-bar"></div>

      <!-- Input Card -->
      <div class="card p-lg mb-lg">
        <div class="form-group mb-md">
          <label class="form-label" id="input-label">Describe your photo</label>
          <textarea class="input" id="creator-input" style="min-height:110px;"></textarea>
        </div>
        <button class="btn btn-primary btn--full" id="creator-btn" style="padding:13px;">
          ${Icons.get('sparkles', 18)} Generate with AI
        </button>
      </div>

      <!-- Result -->
      <div id="creator-result" class="hidden"></div>
    `;

    _renderModes(Helpers.qs('#mode-bar', wrapper), wrapper);
    Helpers.qs('#creator-btn', wrapper).addEventListener('click', () => _generate(wrapper));
    _updatePlaceholder(wrapper);

    return wrapper;
  }

  function _renderModes(container, wrapper) {
    MODES.forEach(mode => {
      const chip = Helpers.el('span', {
        className: `tag ${mode.id === currentMode ? 'active' : ''}`,
        text: mode.label,
        on: {
          click: () => {
            currentMode = mode.id;
            container.querySelectorAll('.tag').forEach(t => t.classList.remove('active'));
            chip.classList.add('active');
            _updatePlaceholder(wrapper);
            // Clear result
            Helpers.qs('#creator-result', wrapper).classList.add('hidden');
            Helpers.qs('#creator-input', wrapper).value = '';
            Helpers.qs('#creator-input', wrapper).focus();
          }
        }
      });
      container.appendChild(chip);
    });
  }

  function _updatePlaceholder(wrapper) {
    const mode = MODES.find(m => m.id === currentMode);
    if (!mode) return;
    const input = Helpers.qs('#creator-input', wrapper);
    if (input) input.placeholder = mode.placeholder;
    const label = Helpers.qs('#input-label', wrapper);
    if (label) label.textContent = mode.label.replace(/^[^\s]+\s/, '');
  }

  async function _generate(wrapper) {
    if (isLoading) return;

    const input = Helpers.qs('#creator-input', wrapper).value.trim();
    if (!input) {
      Helpers.toast('Please enter some details first!', 'danger');
      Helpers.qs('#creator-input', wrapper).focus();
      return;
    }

    isLoading = true;
    const btn = Helpers.qs('#creator-btn', wrapper);
    btn.disabled = true;
    btn.innerHTML = `${Helpers.spinnerHTML('spinner--dark')} Creating...`;

    const modeMeta = MODES.find(m => m.id === currentMode);

    const resultBox = Helpers.qs('#creator-result', wrapper);
    resultBox.classList.remove('hidden');
    resultBox.innerHTML = `
      <div class="result-box">
        <div class="result-box__header">
          <div class="result-box__title">
            ${Icons.get('camera', 18, 'var(--accent2)')} ${modeMeta?.label || 'AI Generated'}
          </div>
          <button class="btn btn-ghost" id="copy-creator" style="padding:6px 12px;font-size:12px;">
            ${Icons.get('copy', 14)} Copy All
          </button>
        </div>
        <div id="creator-content" class="typing-cursor" style="line-height:1.8;font-size:14px;">Generating creative content...</div>
      </div>
    `;

    const contentEl = Helpers.qs('#creator-content', resultBox);
    const promptFn = PROMPTS[currentMode];

    try {
      let fullText = '';
      await API.callClaude(promptFn(input), (text) => {
        fullText = text;
        contentEl.innerHTML = Helpers.formatAIText(text) + '<span class="typing-cursor"></span>';
      });

      contentEl.innerHTML = Helpers.formatAIText(fullText);

      const copyBtn = Helpers.qs('#copy-creator', resultBox);
      copyBtn.addEventListener('click', () => Helpers.copyToClipboard(fullText, copyBtn));

    } catch (err) {
      contentEl.innerHTML = `<div class="alert alert--danger">${Icons.get('alert', 16, 'var(--danger)')} ${err.message}</div>`;
    }

    isLoading = false;
    btn.disabled = false;
    btn.innerHTML = `${Icons.get('sparkles', 18)} Generate with AI`;
    resultBox.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  return { render };
})();
