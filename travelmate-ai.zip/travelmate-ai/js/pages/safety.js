/* ============================================================
   TRAVELMATE AI — SAFETY CENTER & SOS PAGE
   js/pages/safety.js
   ============================================================ */

const SafetyPage = (() => {

  const EMERGENCY_CONTACTS = [
    { flag: '🌍', name: 'International SOS', number: '112'  },
    { flag: '🇮🇳', name: 'India Emergency',   number: '112'  },
    { flag: '🇺🇸', name: 'US Emergency',      number: '911'  },
    { flag: '🇬🇧', name: 'UK Emergency',      number: '999'  },
    { flag: '🇦🇺', name: 'Australia SOS',     number: '000'  },
    { flag: '🇯🇵', name: 'Japan Police',      number: '110'  },
    { flag: '🇩🇪', name: 'Germany SOS',       number: '110'  },
    { flag: '🇫🇷', name: 'France SOS',        number: '17'   },
  ];

  let sosActive    = false;
  let userLocation = null;
  let isLoading    = false;

  function render(user) {
    const wrapper = Helpers.el('div', { className: 'page-wrapper page-enter' });

    wrapper.innerHTML = `
      <div class="section-title">Safety Center</div>
      <div class="section-subtitle">Emergency tools & AI-powered safety guidance</div>

      <!-- SOS Panel -->
      <div class="card mb-lg" id="sos-panel" style="padding:0;">
        <div class="sos-center">
          <div id="sos-alert" class="sos-active-alert hidden">
            🚨 SOS ALERT SENT — Emergency services notified!
          </div>

          <button class="sos-btn" id="sos-button">
            <span class="sos-btn__text">SOS</span>
            <span class="sos-btn__sub">EMERGENCY</span>
          </button>

          <p class="sos-hint">Tap to send emergency alert with your location</p>

          <div id="location-display" class="hidden" style="margin-top:12px;">
            <div class="badge badge--accent" style="margin:0 auto;display:inline-flex;">
              ${Icons.get('pin', 13, 'var(--accent)')}
              <span id="location-text">Fetching location...</span>
            </div>
          </div>
        </div>
      </div>

      <!-- Emergency Numbers -->
      <div class="card p-lg mb-lg">
        <div class="font-display font-bold mb-md" style="font-size:16px;">
          ${Icons.get('phone', 16, 'var(--danger)')} Emergency Numbers
        </div>
        <div class="emergency-grid" id="emergency-grid"></div>
      </div>

      <!-- AI Safety Advisor -->
      <div class="card p-lg mb-lg">
        <div class="font-display font-bold mb-md" style="font-size:16px;">
          ${Icons.get('sparkles', 16, 'var(--accent)')} AI Safety Advisor
        </div>
        <div class="form-group mb-md">
          <label class="form-label">Get safety tips for your destination</label>
          <div class="input-group">
            <input class="input" id="safety-dest" placeholder="Enter destination..." />
            <button class="btn btn-ghost" id="safety-btn" style="flex-shrink:0;">
              ${Icons.get('arrow', 16)} Get Advice
            </button>
          </div>
        </div>
        <div id="safety-result" class="hidden"></div>
      </div>

      <!-- Safety Checklist -->
      <div class="card p-lg">
        <div class="font-display font-bold mb-md" style="font-size:16px;">
          ${Icons.get('check', 16, 'var(--success)')} Pre-Travel Safety Checklist
        </div>
        <div id="checklist"></div>
      </div>
    `;

    _renderEmergencyContacts(Helpers.qs('#emergency-grid', wrapper));
    _renderChecklist(Helpers.qs('#checklist', wrapper));
    _wireSOS(wrapper, user);
    _wireSafetyAdvisor(wrapper);

    return wrapper;
  }

  function _renderEmergencyContacts(container) {
    EMERGENCY_CONTACTS.forEach(c => {
      const card = Helpers.el('a', {
        className: 'emergency-card',
        attrs: { href: `tel:${c.number}` },
        html: `
          <span style="font-size:24px;flex-shrink:0;">${c.flag}</span>
          <div style="flex:1;">
            <div class="emergency-card__label">${c.name}</div>
            <div class="emergency-card__number">${c.number}</div>
          </div>
          ${Icons.get('phone', 16, 'var(--muted)')}
        `
      });
      container.appendChild(card);
    });
  }

  function _renderChecklist(container) {
    const items = [
      { done: true,  text: 'Save emergency contacts offline' },
      { done: true,  text: 'Share itinerary with a trusted person' },
      { done: false, text: 'Purchase travel insurance' },
      { done: false, text: 'Scan passport & keep digital copy' },
      { done: false, text: 'Register with your embassy' },
      { done: false, text: 'Carry local emergency numbers' },
      { done: false, text: 'Download offline maps (Google Maps)' },
      { done: false, text: 'Pack basic first aid essentials' },
    ];

    items.forEach(item => {
      const row = Helpers.el('div', {
        className: 'list-item',
        styles: { cursor: 'pointer' },
        html: `
          <div style="width:22px;height:22px;border-radius:6px;border:2px solid ${item.done ? 'var(--success)' : 'var(--border)'};
            background:${item.done ? 'var(--success)' : 'transparent'};display:flex;align-items:center;justify-content:center;flex-shrink:0;">
            ${item.done ? Icons.get('check', 13, '#080c14') : ''}
          </div>
          <span style="${item.done ? 'color:var(--muted);text-decoration:line-through;' : ''}">${item.text}</span>
        `
      });

      let isDone = item.done;
      row.addEventListener('click', () => {
        isDone = !isDone;
        const icon = row.querySelector('div');
        const text = row.querySelector('span');
        icon.style.borderColor = isDone ? 'var(--success)' : 'var(--border)';
        icon.style.background  = isDone ? 'var(--success)' : 'transparent';
        icon.innerHTML = isDone ? Icons.get('check', 13, '#080c14') : '';
        text.style.color = isDone ? 'var(--muted)' : '';
        text.style.textDecoration = isDone ? 'line-through' : '';
      });

      container.appendChild(row);
    });
  }

  function _wireSOS(wrapper, user) {
    const btn         = Helpers.qs('#sos-button', wrapper);
    const panel       = Helpers.qs('#sos-panel',  wrapper);
    const alert       = Helpers.qs('#sos-alert',  wrapper);
    const locDisplay  = Helpers.qs('#location-display', wrapper);
    const locText     = Helpers.qs('#location-text',    wrapper);

    btn.addEventListener('click', () => {
      if (sosActive) return;
      sosActive = true;

      // Animate panel
      panel.style.background = 'rgba(255,71,87,0.08)';
      panel.style.borderColor = 'rgba(255,71,87,0.3)';

      // Show alert
      alert.classList.remove('hidden');

      // Get location
      locDisplay.classList.remove('hidden');
      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
          pos => {
            userLocation = { lat: pos.coords.latitude, lng: pos.coords.longitude };
            locText.textContent = `${userLocation.lat.toFixed(5)}, ${userLocation.lng.toFixed(5)}`;

            // In a real app: send location + user profile to backend / notify contacts
            console.log('SOS triggered:', { user, location: userLocation, timestamp: new Date().toISOString() });
          },
          () => { locText.textContent = 'Location unavailable'; }
        );
      } else {
        locText.textContent = 'Geolocation not supported';
      }

      Helpers.toast('🚨 SOS Alert Sent!', 'danger');

      // Auto reset after 8 seconds
      setTimeout(() => {
        sosActive = false;
        panel.style.background = '';
        panel.style.borderColor = '';
        alert.classList.add('hidden');
      }, 8000);
    });
  }

  function _wireSafetyAdvisor(wrapper) {
    const btn = Helpers.qs('#safety-btn', wrapper);
    const input = Helpers.qs('#safety-dest', wrapper);

    const run = async () => {
      if (isLoading) return;
      const dest = input.value.trim();
      if (!dest) { Helpers.toast('Please enter a destination', 'danger'); return; }

      isLoading = true;
      btn.disabled = true;
      btn.innerHTML = Helpers.spinnerHTML();

      const resultEl = Helpers.qs('#safety-result', wrapper);
      resultEl.classList.remove('hidden');
      resultEl.innerHTML = `
        <div style="white-space:pre-wrap;line-height:1.8;font-size:14px;" id="safety-content" class="typing-cursor">
          Analyzing safety conditions...
        </div>
      `;

      const contentEl = Helpers.qs('#safety-content', resultEl);

      const prompt = `You are a travel safety expert. Provide essential safety briefing for tourists visiting ${dest}.

🚨 EMERGENCY CONTACTS
- Local police, ambulance, fire brigade numbers
- Tourist helpline (if exists)
- Nearest hospital type/district

🏥 MEDICAL SAFETY
- Water safety (tap water drinkable?)
- Vaccination recommendations
- Common health risks
- Pharmacy availability

🔒 PERSONAL SAFETY
- Overall safety rating for tourists (1-10)
- Areas to avoid (be specific)
- Common scams targeting tourists
- Safe transport options
- Night safety tips

📱 DIGITAL SAFETY
- Useful local emergency apps
- How to reach your country's embassy
- SIM card/data options for connectivity

🌍 NATURAL HAZARDS
- Climate/weather risks for current season
- Natural disaster awareness
- What to do if disaster strikes

📋 DOCUMENTS & LEGAL
- Essential documents to carry
- Medication rules (what's restricted)
- Local laws tourists often break accidentally

💡 STAY SAFE TIPS
- 5 most important safety tips for this destination

Use emojis for readability. Be honest but not alarmist.`;

      try {
        let fullText = '';
        await API.callClaude(prompt, (text) => {
          fullText = text;
          contentEl.innerHTML = Helpers.formatAIText(text) + '<span class="typing-cursor"></span>';
        });
        contentEl.innerHTML = Helpers.formatAIText(fullText);
      } catch (err) {
        contentEl.innerHTML = `<div class="alert alert--danger">${err.message}</div>`;
      }

      isLoading = false;
      btn.disabled = false;
      btn.innerHTML = `${Icons.get('arrow', 16)} Get Advice`;
      resultEl.scrollIntoView({ behavior: 'smooth' });
    };

    btn.addEventListener('click', run);
    input.addEventListener('keydown', e => { if (e.key === 'Enter') run(); });
  }

  return { render };
})();
